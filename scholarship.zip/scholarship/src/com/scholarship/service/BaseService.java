package com.scholarship.service;

public interface BaseService {

}
