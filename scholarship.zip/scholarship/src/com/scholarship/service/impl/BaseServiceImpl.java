package com.scholarship.service.impl;

import com.scholarship.service.BaseService;

public class BaseServiceImpl implements BaseService{

}
