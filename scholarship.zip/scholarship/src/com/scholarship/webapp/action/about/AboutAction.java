package com.scholarship.webapp.action.about;

import com.scholarship.webapp.action.BaseAction;

public class AboutAction extends BaseAction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String about() {
		// TODO Auto-generated method stub
		return SUCCESS;
	}
}
